﻿using FN.Store.UI.Models;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;
using Newtonsoft.Json;
using FN.Store.Data.EF;
using FN.Store.Domain.Helpers;
using FN.Store.Domain.Contracts;
using FN.Store.Data.EF.Repositories;

namespace FN.Store.UI.Controllers
{
    public class ContaController : Controller
    {

        private readonly IUsuarioRepository _usuarioRep =
            new UsuarioRepository();

        [HttpGet]
        public ActionResult Login(string returnUrl)
        {
            return View(new LoginVM() { ReturnUrl = returnUrl});
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        //[RequireHttps]
        public ActionResult Login(LoginVM model)
        {
            var usuario =
                   _usuarioRep.GetByEmail(model.Email);

            if (usuario == null)
            {
                ModelState.AddModelError("Email", "Email não localizado");
            }
            else
            {
                if (usuario.Senha.Encrypt() != model.Senha.Encrypt())
                    ModelState.AddModelError("Senha", "Senha inválida");
            }

            if (ModelState.IsValid)
            {
                var usuarioVM = new UsuarioVM()
                {
                    Id =usuario.Id,
                    Nome = usuario.Nome,
                    Email = usuario.Email,
                    PerfilId = usuario.PerfilId,
                    PerfilNome = usuario.Perfil.Nome
                };
                var json = JsonConvert.SerializeObject(usuarioVM);
                FormsAuthentication.SetAuthCookie(json, false);

                if (!string.IsNullOrEmpty(model.ReturnUrl) && 
                    Url.IsLocalUrl(model.ReturnUrl))
                {
                    return Redirect(model.ReturnUrl);
                }

                return RedirectToAction("Index", "Produtos");
            }


            return View(model);


        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }

        protected override void Dispose(bool disposing)
        {
            _usuarioRep.Dispose();
        }



    }
}
