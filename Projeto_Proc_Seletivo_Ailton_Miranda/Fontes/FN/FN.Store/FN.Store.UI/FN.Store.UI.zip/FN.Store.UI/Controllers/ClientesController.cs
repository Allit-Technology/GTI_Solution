﻿using FN.Store.Data.EF;
using FN.Store.Data.EF.Repositories;
using FN.Store.Domain.Contracts;
using FN.Store.Domain.Entities;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Mvc;
using System.Configuration;
using System.EnterpriseServices;
using System.Runtime.Serialization;
using System.Web.UI;
using System;
using System.ServiceModel;
using System.Data;

namespace FN.Store.UI.Controllers
{
    [Authorize]
    public class ClientesController:Controller
    {
        private readonly FNStoreDataContext _ctx = new FNStoreDataContext();
        private readonly IClienteRepository _clienteRepository;
        private readonly IEstadoCivilRepository _estadoCivilRep;
        private readonly IUnidadeFederativaRepository _unidadeFederativaRep;
        private readonly ISexoRepository _sexoRep;
        private readonly IClientesEnderecoRepository _clienteEnderecoRep;

        public ClientesController()
        {
            _clienteRepository = new ClienteRepository();
            _estadoCivilRep = new EstadoCivilRepository();
            _unidadeFederativaRep = new UnidadeFederativaRepository();
            _sexoRep = new SexoRepository();
            _clienteEnderecoRep = new ClienteEnderecoRepository();
        }

        public ActionResult Index()
        {
            //Via MVC
            var model = _clienteRepository.Get();
            return View(model);
        }

        public ActionResult IndexEndereco(int? id)
        {
            var model = _clienteEnderecoRep.GetByClientId((int)id);
            IEnumerable<Cliente> cliente;
            cliente = _clienteRepository.GetById((int)id);
            ViewBag.tabcliente = cliente;
            return View(model);
        }

        public ActionResult AddEdit(int? id)
        {
            var model = new Cliente();

            if (id != null)
            {
                model = _clienteRepository.Get(id);

                if (model == null)
                    return HttpNotFound();

            }

            var estadocivil = _estadoCivilRep.Get();
            ViewBag.tabestadocivil = estadocivil;

            var unidadefederativa = _unidadeFederativaRep.Get();
            ViewBag.tabunidadefederativa = unidadefederativa;

            var sexo = _sexoRep.Get();
            ViewBag.tabsexo = sexo;

            return View(model);
        }

        public ActionResult AddEditEndereco(int? id, int? clienteid)
        {
            var model = new ClientesEndereco();

            if (id != null)
            {
                model = _ctx.ClientesEndereco.Where(ce => ce.Id == id && ce.ClienteId == clienteid).FirstOrDefault();
            }

            var unidadefederativa = _unidadeFederativaRep.Get();
            ViewBag.tabunidadefederativa = unidadefederativa;

            IEnumerable<Cliente> cliente;
            cliente = _clienteRepository.GetById((int)id);
            ViewBag.tabcliente = cliente;

            return View(model);
        }

        [HttpGet]
        public ViewResult AddEditEndereco1(int? id)
        {
            //Insert Via WCF
            ClientesEndereco clientesEndereco = new ClientesEndereco();

            if (id != null)
            {
                clientesEndereco = _ctx.ClientesEndereco.Where(ce => ce.ClienteId == id).FirstOrDefault();
                gtiServices.ServiceClient clienteEnderecoService = new gtiServices.ServiceClient();
                var clientEndereco = clienteEnderecoService.GetClienteEndereco((int)id);

                if (clientesEndereco == null)
                    return View(IndexEndereco(id));
            }

            var unidadefederativa = _unidadeFederativaRep.Get();
            ViewBag.tabunidadefederativa = unidadefederativa;

            var clientes_endereco = _ctx.ClientesEndereco.ToList();
            ViewBag.endereco = clientes_endereco;

            var clientes = _ctx.Clientes.ToList();
            ViewBag.tabcliente = clientes;

            return View(clientesEndereco);
        }

        [HttpGet]
        public ViewResult AddEditEnderecoGrid(int? id)
        {
            ClientesEndereco clientesEndereco = new ClientesEndereco();
            Cliente modelcliente = new Cliente();

            if (id != null)
            {
                clientesEndereco = _ctx.ClientesEndereco.Where(ce => ce.ClienteId == id).FirstOrDefault();
                modelcliente = _ctx.Clientes.Find(id);
            }
            
            var unidadefederativa = _unidadeFederativaRep.Get();
            ViewBag.tabunidadefederativa = unidadefederativa;

            var clientesEnderecol = _ctx.ClientesEndereco.ToList();
            ViewBag.endereco = clientesEnderecol;

            IEnumerable<Cliente> cliente;
            cliente = _clienteRepository.GetById((int)id);
            ViewBag.tabcliente = cliente;

            return View(clientesEndereco);
        }

        [HttpPost,ValidateAntiForgeryToken]
        public ActionResult AddEdit(Cliente model)
        {
            //Insert Via WCF
            gtiServices.ServiceClient cliente = new gtiServices.ServiceClient();
            if (ModelState.IsValid)
            {
                if (model.Id == 0)
                {
                    cliente.InsertCliente(model.Nome, model.Cpf, model.Rg, model.DataExpedicao.Date, model.OrgaoExpedicao, model.DataNascimento.Date, model.EstadoCivilId, model.UFId, model.SexoId);
                }
                else
                {
                    cliente.UpdateCliente(model.Id, model.Nome, model.Cpf, model.Rg, model.DataExpedicao, model.OrgaoExpedicao, model.DataNascimento, model.EstadoCivilId, model.UFId, model.SexoId);
                }
                
                cliente.Close();

                return RedirectToAction("Index");
            }
            
            var estadocivil = _estadoCivilRep.Get();
            ViewBag.tabestadocivil = estadocivil;

            var unidadefederativa = _unidadeFederativaRep.Get();
            ViewBag.tabunidadefederativa = unidadefederativa;

            var sexo = _sexoRep.Get();
            ViewBag.tabsexo = sexo;

            return View(model);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult AddEditEndereco(ClientesEndereco model)
        {
            //Insert Via WCF
            var id = 0;
            if (model.ClienteId == 0)
            {
                if (model.Id != 0)
                {
                    id = model.Id;
                }
            } else
            {
                id = model.ClienteId;
            }
            gtiServices.ServiceClient clienteEndereco = new gtiServices.ServiceClient();
            var client = clienteEndereco.GetClienteEnderecoLog(id, model.Logradouro);
            if (client.ClienteEnderecoTable.Rows.Count != 0)
            {
                foreach (DataRow dr in client.ClienteEnderecoTable.Rows)
                {
                    clienteEndereco.UpdateClienteEndereco(int.Parse(dr["Id"].ToString()), dr["Cep"].ToString(), dr["Logradouro"].ToString(), dr["Numero"].ToString(), dr["Complemento"].ToString(), dr["Bairro"].ToString(), dr["Cidade"].ToString(), int.Parse(dr["ClienteId"].ToString()), int.Parse(dr["UFId"].ToString()));
                }
            }
            else
            {
                clienteEndereco.InsertClienteEndereco(model.Cep, model.Logradouro, model.Numero, model.Complemento, model.Bairro, model.Cidade, id, model.UFId);
            }

            clienteEndereco.Close();

            IEnumerable<Cliente> cliente;
            cliente = _clienteRepository.GetById((int)model.Id);
            ViewBag.tabcliente = cliente;

            var unidadefederativa = _unidadeFederativaRep.Get();
            ViewBag.tabunidadefederativa = unidadefederativa;

            return View(IndexEndereco(id));
        }

        [HttpPost]
        public JsonResult Excluir(int id)
        {
            var success = false;
            var msg = "Cliente não excluído";

            //Delete Via WCF
            gtiServices.ServiceClient cliente = new gtiServices.ServiceClient();
            var client = cliente.GetCliente(id);
            if (client != null)
            {
                String ID = "";
                foreach (DataRow dr in client.ClienteTable.Rows)
                {
                    ID = dr["Id"].ToString();
                }
                
                cliente.DeleteCliente(int.Parse(ID));
                success = true;
                msg = "Cliente excluído c/ sucesso!";
            }

            return Json(new { success, msg });
        }


        [HttpPost]
        public JsonResult ExcluirEndereco(int? id)
        {
            var success = false;
            var msg = "Endereço não excluído";

            //Delete Via WCF
            gtiServices.ServiceClient cliente = new gtiServices.ServiceClient();
            var client = cliente.GetClienteEndereco((int)id);
            if (client != null)
            {
                cliente.DeleteClienteEndereco((int)id);
                success = true;
                msg = "Endereço excluído c/ sucesso!";
            }

            return Json(new { success, msg });
        }

        protected override void Dispose(bool disposing)
        {
            _clienteRepository.Dispose();
            _estadoCivilRep.Dispose();
            _unidadeFederativaRep.Dispose();
            _sexoRep.Dispose();
            _clienteEnderecoRep.Dispose();
        }

    }
}
