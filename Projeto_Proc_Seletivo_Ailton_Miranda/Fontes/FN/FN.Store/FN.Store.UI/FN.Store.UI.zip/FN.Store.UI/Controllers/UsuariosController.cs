﻿using FN.Store.Domain.Contracts;
using FN.Store.Domain.Entities;
using FN.Store.Domain.Helpers;
using FN.Store.UI.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace FN.Store.UI.Controllers
{
    [AuthorizeCustom("Admin")]
    public class UsuariosController : Controller
    {
        private readonly IUsuarioRepository _usuarioRepository;
        private readonly IPerfilRepository _perfilRepository;

        public UsuariosController(
            IUsuarioRepository usuarioRepository, IPerfilRepository perfilRepository
        )
        {
            _usuarioRepository = usuarioRepository;
            _perfilRepository = perfilRepository;
        }

        [AllowAnonymous]
        public ActionResult Index()
        {
            var model = _usuarioRepository.Get();
            return View(model);
        }


        public ActionResult AddEdit(int? id)
        {
            var model = new Usuario();

            if (id != null)
            {
                model = _usuarioRepository.Get(id);

                if (model == null)
                    return HttpNotFound();

            }

            var perfis = _perfilRepository.Get();
            ViewBag.Perfis = perfis;
            return View(model);
        }

        [HttpPost,ValidateAntiForgeryToken]
        public ActionResult AddEdit(Usuario model)
        {
            if (ModelState.IsValid)
            {
                model.Senha = model.Senha.Encrypt();
                if (model.Id == 0)
                {
                    _usuarioRepository.Add(model);
                }
                else
                {
                    _usuarioRepository.Update(model);
                }
                return RedirectToAction("Index");
            }

            return View(model);
        }

        [HttpPost]
        public JsonResult Excluir(int id)
        {
            var success = false;
            var msg = "Usuário não excluído";

            var usuario = _usuarioRepository.Get(id);
            if (usuario != null)
            {
                _usuarioRepository.Delete(usuario);
                success = true;
                msg = "Usuário excluído c/ sucesso!";
            }

            return Json(new { success, msg });
        }



        protected override void Dispose(bool disposing)
        {
            _usuarioRepository.Dispose();
            _perfilRepository.Dispose();
        }



    }
}
