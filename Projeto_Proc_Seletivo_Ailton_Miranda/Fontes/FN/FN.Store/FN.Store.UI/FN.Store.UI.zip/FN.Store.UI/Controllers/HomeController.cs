﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace FN.Store.UI.Controllers
{
    public class HomeController : Controller
    {

        public ViewResult Index() => View();
        //{
        //    return View();
        //}


        [Route("Sobre")]
        public ActionResult About()
        {
            //throw new Exception("Deu Ruim");
            return View();
        }

    }
}
