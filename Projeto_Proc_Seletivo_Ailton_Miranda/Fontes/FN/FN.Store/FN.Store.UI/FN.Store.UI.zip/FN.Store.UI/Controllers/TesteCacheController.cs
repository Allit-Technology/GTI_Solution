﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace FN.Store.UI.Controllers
{
    public class TesteCacheController : Controller
    {
        [OutputCache(Duration = 10)]
        public ActionResult Index()
        {
            var model = new Random().Next(1000);
            return View(model);
        }
    }
}
