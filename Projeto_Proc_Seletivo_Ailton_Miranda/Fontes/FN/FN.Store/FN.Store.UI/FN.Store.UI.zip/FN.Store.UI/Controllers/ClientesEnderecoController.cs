﻿using FN.Store.Data.EF.Repositories;
using FN.Store.Domain.Contracts;
using FN.Store.Domain.Entities;
using System;
using System.Data;
using System.Web.Mvc;

namespace FN.Store.UI.Controllers
{
    [Authorize]
    public class ClientesEnderecoController : Controller
    {
        private readonly IClientesEnderecoRepository _clienteEnderecoRep;
        private readonly IUnidadeFederativaRepository _unidadeFederativaRep;
        private readonly IClienteRepository _clienteRep;
        
        public ClientesEnderecoController()
        {
            _clienteEnderecoRep = new ClienteEnderecoRepository();
            _unidadeFederativaRep = new UnidadeFederativaRepository();
            _clienteRep = new ClienteRepository();
        }

        public ActionResult Index(int? Id)
        {
            var model = _clienteEnderecoRep.GetByClientId((int)Id);
            return View(model);
        }

        public ActionResult AddEdit(int? id)
        {
            var model = new ClientesEndereco();

            if (id != null)
            {
                model = _clienteEnderecoRep.Get(id);

                if (model == null)
                    return HttpNotFound();

            }

            var unidadefederativa = _unidadeFederativaRep.Get();
            ViewBag.tabunidadefederativa = unidadefederativa;

            var cliente = _clienteRep.Get();
            ViewBag.tabcliente = cliente;

            return View(model);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult AddEdit(ClientesEndereco model)
        {
            //Insert Via WCF
            gtiServices.ServiceClient clienteEndereco = new gtiServices.ServiceClient();
            if (ModelState.IsValid)
            {
                if (model.Id == 0)
                {
                    clienteEndereco.InsertClienteEndereco(model.Cep, model.Logradouro, model.Numero, model.Complemento, model.Bairro, model.Cidade, model.ClienteId, model.UFId);
                }
                else
                {
                    clienteEndereco.UpdateClienteEndereco(model.Id, model.Cep, model.Logradouro, model.Numero, model.Complemento, model.Bairro, model.Cidade, model.ClienteId, model.UFId);
                }

                return RedirectToAction("Index");
            }

            clienteEndereco.Close();

            var unidadefederativa = _unidadeFederativaRep.Get();
            ViewBag.tabunidadefederativa = unidadefederativa;

            var cliente = _clienteRep.Get();
            ViewBag.tabcliente = cliente;

            return View(model);
        }

        [HttpPost]
        public JsonResult Excluir(int id)
        {
            var success = false;
            var msg = "Endereço não excluído";

            gtiServices.ServiceClient clienteEndereco = new gtiServices.ServiceClient();
            var clientEndereco = clienteEndereco.GetClienteEndereco(id);
            if (clientEndereco != null)
            {
                String ID = "";
                foreach (DataRow dr in clientEndereco.ClienteEnderecoTable.Rows)
                {
                    ID = dr["Id"].ToString();
                }

                clienteEndereco.DeleteClienteEndereco(int.Parse(ID));
                success = true;
                msg = "Endereço excluído c/ sucesso!";
            }

            return Json(new { success, msg });
        }

        protected override void Dispose(bool disposing)
        {
            _clienteEnderecoRep.Dispose();
            _unidadeFederativaRep.Dispose();
            _clienteRep.Dispose();
        }

    }
}
