﻿using FN.Store.UI.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace FN.Store.UI.Filters
{
    public class AuthorizeCustom: AuthorizeAttribute
    {
        private readonly List<string> _perfis;
        public AuthorizeCustom(string perfis)
        {
            _perfis = perfis.Split(',').ToList();
        }


        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            if (!httpContext.User.Identity.IsAuthenticated)
                return false;

            var user = JsonConvert.DeserializeObject<UsuarioVM>(httpContext.User.Identity.Name);
            return _perfis.Contains(user.PerfilNome);
        }


    }
}
