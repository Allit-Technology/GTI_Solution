﻿namespace FN.Store.UI.Models
{
    public class UsuarioVM
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public int PerfilId { get; set; }
        public string PerfilNome { get; set; }
    }
}
