﻿using System.ComponentModel.DataAnnotations;

namespace FN.Store.UI.Models
{
    public class LoginVM
    {
        [Required(ErrorMessage ="O email é obrigatório")]
        [StringLength(100, ErrorMessage ="Limite excedido")]
        [RegularExpression(@"([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)",
            ErrorMessage ="Email inválido")]
        public string Email { get; set; }

        [Required(ErrorMessage ="A senha é obrigatória")]
        [StringLength(100, ErrorMessage ="Limite excedido")]
        public string Senha { get; set; }

        public string ReturnUrl { get; set; }

    }
}
