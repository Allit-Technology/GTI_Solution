﻿function SalvarVenda() {

    debugger;

    //Cliente
    var cliente = $("#txtCliente option:selected").val();
    
    //TotalVenda
    var totalvenda = $('#txtTotalVenda').val();

    var token = $('input[name="__RequestVerificationToken"]').val();
    var tokenadr = $('form[action="/Venda/AddEdit"] input[name="__RequestVerificationToken"]').val();
    var headers = {};
    var headersadr = {};
    headers['__RequestVerificationToken'] = token;
    headersadr['__RequestVerificationToken'] = tokenadr;

    //Gravar

    var url = "~/Venda/AddEdit";

    $.ajax({
        url: URL
        , type: "POST"
        , datatype: "json"
        , headers: headersadr
        , data: { Id: 0, TotalVenda: totalvenda, ClienteId: cliente, __RequestVerificationToken: token }
        , sucess: function (data) {
            if (data.Resultado > 0) {

                debugger;
                //ListarItens(data.Resultado);
            }
        }
    });
}