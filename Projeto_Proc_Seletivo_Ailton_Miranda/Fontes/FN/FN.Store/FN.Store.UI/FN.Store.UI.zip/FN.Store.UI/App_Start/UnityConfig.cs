using EF = FN.Store.Data.EF.Repositories;
using FN.Store.Domain.Contracts;
using System;

using Unity;

namespace FN.Store.UI
{

    public static class UnityConfig
    {

        private static Lazy<IUnityContainer> container =
          new Lazy<IUnityContainer>(() =>
          {
              var container = new UnityContainer();
              RegisterTypes(container);
              return container;
          });

        
        public static IUnityContainer Container => container.Value;

        public static void RegisterTypes(IUnityContainer container)
        {
            container.RegisterType<IUsuarioRepository, EF.UsuarioRepository>();
            container.RegisterType<IClienteRepository, EF.ClienteRepository>();
            container.RegisterType<IPerfilRepository, EF.PerfilRepository>();
        }
    }
}