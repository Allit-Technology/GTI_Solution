﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Unity;

namespace FN.Store.UI
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            //Passa no método que registra as dependências dos controllers
            UnityConfig.RegisterTypes(new UnityContainer());
            RouteConfig.RegisterRoutes(RouteTable.Routes);
        }

        //CrossCutting
        //Elemar Jr.
    }
}
